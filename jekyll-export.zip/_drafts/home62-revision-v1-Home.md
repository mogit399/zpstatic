---
id: 312
title: Home
date: '2022-02-16T15:21:44+00:00'
author: mos
layout: revision
guid: 'https://ashleysflowery.com/?p=312'
permalink: '/?p=312'
panels_data:
    - "a:3:{s:7:\"widgets\";a:1:{i:0;a:9:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:75:\"<h2 style=\"text-align: center;\">Hello Wolrd!\n<p>[fvplayer id=\"1\"]</p></h2>\n\";s:20:\"text_selected_editor\";s:4:\"tmce\";s:5:\"autop\";b:1;s:12:\"_sow_form_id\";s:32:\"1821783269620d148dd8e42494167542\";s:19:\"_sow_form_timestamp\";s:13:\"1645024893599\";s:11:\"panels_info\";a:6:{s:5:\"class\";s:31:\"SiteOrigin_Widget_Editor_Widget\";s:4:\"grid\";i:0;s:4:\"cell\";i:0;s:2:\"id\";i:0;s:9:\"widget_id\";s:36:\"28fc31c9-1e5a-4928-a8c3-95d79d29e8ee\";s:5:\"style\";a:2:{s:27:\"background_image_attachment\";b:0;s:18:\"background_display\";s:4:\"tile\";}}s:22:\"so_sidebar_emulator_id\";s:19:\"sow-editor-31210000\";s:11:\"option_name\";s:17:\"widget_sow-editor\";}}s:5:\"grids\";a:1:{i:0;a:4:{s:5:\"cells\";i:1;s:5:\"style\";a:3:{s:27:\"background_image_attachment\";b:0;s:18:\"background_display\";s:4:\"tile\";s:14:\"cell_alignment\";s:10:\"flex-start\";}s:5:\"ratio\";i:1;s:15:\"ratio_direction\";s:5:\"right\";}}s:10:\"grid_cells\";a:1:{i:0;a:4:{s:4:\"grid\";i:0;s:5:\"index\";i:0;s:6:\"weight\";i:1;s:5:\"style\";a:0:{}}}}"
---

<div class="panel-layout" id="pl-312"><div class="panel-grid panel-no-style" id="pg-312-0"><div class="panel-grid-cell" id="pgc-312-0-0"><div class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="0" id="panel-312-0-0-0"><div class="so-widget-sow-editor so-widget-sow-editor-base"><div class="siteorigin-widget-tinymce textwidget">## Hello Wolrd! <div class="flowplayer no-brand is-splash no-svg is-paused skin-slim fp-slim fp-edgy" data-fv-embed="https://ashleysflowery.com/?p=312/fvp-1/" data-item="{"sources":[{"src":"https:\/\/iptv.mihantv.com\/live\/playlist.m3u8","type":"application\/x-mpegurl"}],"live":"true","id":"1"}" data-ratio="0.5625" id="wpfp_962ce6cb1db8507f6a689a47db23de22" style="max-width: 640px; max-height: 360px; "><div class="fp-ratio" style="padding-top: 56.25%"></div><div class="fp-ui"><noscript>Please enable JavaScript</noscript><div class="fp-preload"></div></div><div class="fvfp_admin_error" id="wpfp_962ce6cb1db8507f6a689a47db23de22_admin_error"><div class="fvfp_admin_error_content">#### Admin JavaScript warning:

I'm sorry, your JavaScript appears to be broken. Please use "Check template" in plugin settings, read our [troubleshooting guide](https://foliovision.com/player/installation#fixing-broken-javascript), [troubleshooting guide for programmers](https://foliovision.com/troubleshooting-javascript-errors) or [order our pro support](https://foliovision.com/pro-support) and we will get it fixed for you.

</div></div><div class="fvp-share-bar">- [](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fashleysflowery.com%2F%3Fp%3D312)
- [](https://twitter.com/intent/tweet?text=Mo+Site1+&url=https%3A%2F%2Fashleysflowery.com%2F%3Fp%3D312)
- [](mailto:?body=Check%20out%20the%20amazing%20video%20here%3A%20https%3A%2F%2Fashleysflowery.com%2F%3Fp%3D312)

<div>[Link](https://ashleysflowery.com/?p=312)</div><div><label>[**Embed**](#)</label></div><div class="embed-code"><label>Copy and paste this HTML code into your webpage to embed.</label><textarea></textarea></div></div></div>

</div></div></div></div></div></div>