---
id: 39
title: twentytwenty
date: '2020-04-28T21:13:55+00:00'
author: mos
layout: revision
guid: 'https://ashleysflowery.com/38-revision-v1/'
permalink: '/?p=39'
---

.container {  
 width: 77%;  
}