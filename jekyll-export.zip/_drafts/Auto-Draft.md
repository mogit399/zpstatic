---
id: 347
title: 'Auto Draft'
date: '2022-02-17T20:02:53+00:00'
author: mos
layout: post
guid: 'https://ashleysflowery.com/?p=347'
permalink: '/?p=347'
vantage_panels_no_legacy:
    - 'true'
---

